
package com.capgemini.stargate.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.stargate.controller.model.Statement;
import com.capgemini.stargate.dao.StatementsCrudRepositeryImpl;


/**
 * Its Controller class and get called as per URI mapped for this. * 
 */
@RestController
@RequestMapping(value = "/api/v1/statements", produces = "application/json")
@Validated
//@EnableOAuth2Sso
public class StatementIdController {
	
	@Autowired
	StatementsCrudRepositeryImpl repoObj = new StatementsCrudRepositeryImpl();
	//use dao\service layer
		
	//@Autowired
    //private  MessageProducer messageProducer;	
	
	
    /**
     * method getStatements method takes accountId, accoutType, startTime, endTime
     * it return list of statements of given date range
     */
    @SuppressWarnings("unchecked")
	@RequestMapping(value = "", method = RequestMethod.GET)
    public List<Statement> getStatements(    		
        @RequestParam(required = true)
        String accountId,
        
        @RequestParam(required = true)
        String accountType,
        
        @RequestParam(required = true)
        @DateTimeFormat(pattern = "yyyy-MM-dd")
        Date startTime,
        
        @RequestParam(required = true)
        @DateTimeFormat(pattern = "yyyy-MM-dd")
        Date endTime)
    {
    	//catch all user defined exception here. 
    	List<Statement> list = new ArrayList<Statement>();
    	//list =  repoObj.fetchStatementList(accountId, accountType, startTime, endTime);
    	list = repoObj.getStatements(accountId, accountType, startTime, endTime);
    	System.out.println(" accountId ::: " + accountId);
    	//messageProducer.sendMessage(list);
    	return list;
        
    }
    
    /*
     * Used for oAuth2 Validation
     */
    /*protected void configure(HttpSecurity http) throws Exception {
      http
        .antMatcher("/**")
        .authorizeRequests()
          .antMatchers("/", "/login**", "/webjars/**", "/error**")
          .permitAll()
        .anyRequest()
          .authenticated();
    }*/

}
