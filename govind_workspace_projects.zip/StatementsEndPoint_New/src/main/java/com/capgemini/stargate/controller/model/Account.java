
package com.capgemini.stargate.controller.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/*
 * Account is pojo class with necessary variables & methods & annotations its generated from RAML plugin
 */
@Entity
public class Account extends AccountDescriptor implements Serializable
{

    final static long serialVersionUID = 3847515450272278715L;
    
    //@Id
    @Column(name="AccountMasterId")
	protected Double accountMasterId;
    
    @Column(name="ParentAccountId")
    private String parentAccountId;
    
    @Column(name="Nickname")
    private String nickname;
    
    @Column(name="AccountNumber")
    private String accountNumber;
    
    @Column(name="InterestRate")
    private Double interestRate;
    
    @Enumerated(EnumType.STRING)
    private com.capgemini.stargate.controller.model.Currency Currency;

    /**
     * Creates a new Account.
     * 
     */
    public Account() {
        super();
    }

    /**
     * Creates a new Account.
     * 
     */
    public Account(Double accountMasterId, String accountId, AccountType accountType, String displayName, String description, AccountStatus accountStatus, String parentAccountId, String nickname, String accountNumber, Double interestRate, 
    		       Double accountDescriptorId,com.capgemini.stargate.controller.model.Currency Currency) {
        super(accountId, accountType, displayName, description, accountStatus, accountDescriptorId);
        this.parentAccountId = parentAccountId;
        this.nickname = nickname;
        this.accountNumber = accountNumber;
        this.interestRate = interestRate;
        this.Currency = Currency;
        this.accountDescriptorId = accountDescriptorId;
        this.accountMasterId = accountMasterId;
    }
    

	/**
     * Returns the parentAccountId.
     * 
     * @return
     *     parentAccountId
     */
    public String getParentAccountId() {
        return parentAccountId;
    }

    /**
     * Set the parentAccountId.
     * 
     * @param parentAccountId
     *     the new parentAccountId
     */
    public void setParentAccountId(String parentAccountId) {
        this.parentAccountId = parentAccountId;
    }

    /**
     * Returns the nickname.
     * 
     * @return
     *     nickname
     */
    public String getNickname() {
        return nickname;
    }

    /**
     * Set the nickname.
     * 
     * @param nickname
     *     the new nickname
     */
    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    /**
     * Returns the accountNumber.
     * 
     * @return
     *     accountNumber
     */
    public String getAccountNumber() {
        return accountNumber;
    }

    /**
     * Set the accountNumber.
     * 
     * @param accountNumber
     *     the new accountNumber
     */
    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    /**
     * Returns the interestRate.
     * 
     * @return
     *     interestRate
     */
    public Double getInterestRate() {
        return interestRate;
    }

    /**
     * Set the interestRate.
     * 
     * @param interestRate
     *     the new interestRate
     */
    public void setInterestRate(Double interestRate) {
        this.interestRate = interestRate;
    }

    /**
     * Returns the Currency.
     * 
     * @return
     *     Currency
     */
    public com.capgemini.stargate.controller.model.Currency getCurrency() {
        return Currency;
    }

    /**
     * Set the Currency.
     * 
     * @param Currency
     *     the new Currency
     */
    public void setCurrency(com.capgemini.stargate.controller.model.Currency Currency) {
        this.Currency = Currency;
    }
    
    public Double getAccountMasterId() {
		return accountMasterId;
	}

	public void setAccountMasterId(Double accountMasterId) {
		this.accountMasterId = accountMasterId;
	}

    public int hashCode() {
        return new HashCodeBuilder().appendSuper(super.hashCode()).append(parentAccountId).append(nickname).append(accountNumber).append(interestRate).append(Currency).toHashCode();
    }

    public boolean equals(Object other) {
        if (other == null) {
            return false;
        }
        if (other == this) {
            return true;
        }
        if (this.getClass()!= other.getClass()) {
            return false;
        }
        Account otherObject = ((Account) other);
        return new EqualsBuilder().appendSuper(super.equals(otherObject)).append(parentAccountId, otherObject.parentAccountId).append(nickname, otherObject.nickname).append(accountNumber, otherObject.accountNumber).append(interestRate, otherObject.interestRate).append(Currency, otherObject.Currency).isEquals();
    }

    public String toString() {
        return new ToStringBuilder(this).appendSuper(super.toString()).append("parentAccountId", parentAccountId).append("nickname", nickname).append("accountNumber", accountNumber).append("interestRate", interestRate).append("Currency", Currency).toString();
    }

}
