package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.controller.model.Loanaccount;
import com.example.demo.dao.LoanAccountBaseRepository;

@Service
public class LoanAccountBaseRepositoryImpl {

	
	@Autowired
	public LoanAccountBaseRepository loanAccountBaseRepository;
	
	 public List<Loanaccount> getAllLoanAccount(String paymentFrequency){
		 
		List<Loanaccount> listaccount= loanAccountBaseRepository.fetchLoanaccountDetails(paymentFrequency);
		
		return listaccount;
	 }
	
}
