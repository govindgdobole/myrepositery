package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.repositery.SystemRepository;



@RestController
@RequestMapping(value="/api/v1")
public class MysqlJdbcDriverApplication implements CommandLineRunner {
 
    @Autowired
    SystemRepository systemRepository;
 
    @Override
    @GetMapping(value= "/system")
    public void run(String... args) throws Exception {       
        
        Iterable<System> systemlist = systemRepository.findAll();
        for(System systemmodel:systemlist){
            System.out.println("Here is a system: " + systemmodel.toString());
        }
         
 
    }
 
}
