package com.capgemini.stargate.dao;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Repository;

import com.capgemini.stargate.controller.model.Statement;
import com.capgemini.stargate.repositery.StatementsCrudRepositeryInterface;

@SuppressWarnings("rawtypes")
@Repository
@Transactional

public class StatementsCrudRepositeryImpl  implements StatementsCrudRepositeryInterface
{
	
	@PersistenceContext
    EntityManager entityManager;


	@Override
	public void deleteAllInBatch() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteInBatch(Iterable arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List findAll(Sort arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List findAll(Example arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List findAll(Example arg0, Sort arg1) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List findAllById(Iterable arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void flush() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Object getOne(Object arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List saveAll(Iterable arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object saveAndFlush(Object arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Page findAll(Pageable arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long count() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void delete(Object arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteAll() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteAll(Iterable arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteById(Object arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean existsById(Object arg0) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Optional findById(Object arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object save(Object arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long count(Example arg0) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean exists(Example arg0) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Page findAll(Example arg0, Pageable arg1) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional findOne(Example arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Statement> fetchStatementList(String accountId, String accoutType, Date startDate, Date endDate) 
	{
		Query query = entityManager.createNativeQuery("SELECT * "
				+ "FROM statement , accountdescriptor "
				+ "WHERE  statement.AccountId = accountdescriptor.AccountId "
				+ "AND statement.StatementDate BETWEEN '2018-01-01' AND '2018-04-04'", Statement.class);
		
		System.out.println(" Result ::: " + query.getResultList());	
		
		
		return query.getResultList();
		
		/*
		 * SELECT statement.AccountId, statement.StatementId, statement.Description, statement.StatementDate
FROM statement , accountdescriptor
WHERE  statement.AccountId = accountdescriptor.AccountId
AND statement.StatementDate BETWEEN '2018-01-01' AND '2018-04-04'
		 */
	}
	
}
