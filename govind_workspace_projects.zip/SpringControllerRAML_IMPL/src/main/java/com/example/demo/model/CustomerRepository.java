package com.example.demo.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;
import org.springframework.util.Assert;


@Component
public class CustomerRepository {
	private static final Map<Integer, Customer> cust = new HashMap<>();

	@PostConstruct
	public void initData() {
		
		Customer cs1 = new Customer();
		cs1.setCustomerId(1);
		cs1.setCustomerName("Govind");
		cs1.setAddress("Pune");
		cs1.setEmailid("govind@mail.com");
		
		cust.put(cs1.getCustomerId(), cs1);
		
		Customer cs2 = new Customer();
		cs2.setCustomerId(1);
		cs2.setCustomerName("Akash");
		cs2.setAddress("Mumbai");
		cs2.setEmailid("akash@mail.com");
		
		cust.put(cs2.getCustomerId(), cs2);
		
		Customer cs3 = new Customer();
		cs3.setCustomerId(1);
		cs3.setCustomerName("Neha");
		cs3.setAddress("Banglore");
		cs3.setEmailid("neha@mail.com");
		
		cust.put(cs3.getCustomerId(), cs3);
	}
	
	/*
	 * Return customers with particular id
	 */
	public Customer getCustomerByID(int id) {		
		Assert.notNull(cust.size(), "There is no Customer Present");				
		return cust.get(id);
	}
	
	/*
	 * Returns list of all customers( converts from map to list)
	 * 
	 */
	public List<Customer> allCustList()
	{
		List<Customer> custList = new ArrayList<>();	
		
		Set<Integer> ids = cust.keySet();
		for(Integer id: ids){
			custList.add(cust.get(id));
			id++;
		}
		return custList;
	}	
	
}
