package com.example.demo.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.demo.controller.model.Loanaccount;

@SuppressWarnings("hiding")
@Repository
public interface LoanAccountBaseRepository extends CrudRepository<Loanaccount, String> {

	@Query(value = "SELECT * " + " from loanaccount la , account acc, accountdescriptor asd"
			+ " where la.AccountrefId = acc.AccountMasterId and "
			+ "acc.AccDescriptorId = asd.AccountDescriptorId and la.PaymentFrequency = :paymentFrequency", nativeQuery = true)
	public List<Loanaccount> fetchLoanaccountDetails(@Param("paymentFrequency") String paymentFrequency);
}
