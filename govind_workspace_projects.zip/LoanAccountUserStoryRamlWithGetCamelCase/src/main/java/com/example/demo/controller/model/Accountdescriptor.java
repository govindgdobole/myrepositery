
package com.example.demo.controller.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.MappedSuperclass;
import javax.persistence.Table;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.lang.Nullable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


@Entity
@Table(name = "accountdescriptor")
//@Inheritance(strategy = InheritanceType.JOINED)
@JsonIgnoreProperties({"accountDescriptorId", "accountId"})

public class Accountdescriptor implements Serializable
{

    final static long serialVersionUID = -1840211957440959443L;
    @Column
    private String accountId;
    @Column
    @Enumerated(EnumType.STRING)
    private IdentifierforAccounttype accountType;
    @Column(nullable=true)
    private String displayName;
    @Column(nullable=true)
    private String description;
    @Column
    @Enumerated(EnumType.STRING)
    private IdentifierforAccoundstatus status;
    @Id
    @Column(name="AccountDescriptorId")
    private Double accountDescriptorId;
    @Column
    private String customerId;

    /**
     * Creates a new Accountdescriptor.
     * 
     */
    public Accountdescriptor() {
        super();
    }

    /**
     * Creates a new Accountdescriptor.
     * 
     */
    public Accountdescriptor(String accountId, IdentifierforAccounttype accountType, String displayName, String description, IdentifierforAccoundstatus status, Double accountDescriptorId, String customerId) {
        super();
        this.accountId = accountId;
        this.accountType = accountType;
        this.displayName = displayName;
        this.description = description;
        this.status = status;
        this.accountDescriptorId = accountDescriptorId;
        this.customerId = customerId;
    }
   
    public Accountdescriptor( Double accountDescriptorId) {
        super();
      
        this.accountDescriptorId = accountDescriptorId;
        
    }
    
    /**
     * Returns the accountId.
     * 
     * @return
     *     accountId
     */
    public String getAccountId() {
        return accountId;
    }

    /**
     * Set the accountId.
     * 
     * @param accountId
     *     the new accountId
     */
    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    /**
     * Returns the accountType.
     * 
     * @return
     *     accountType
     */
    public IdentifierforAccounttype getAccountType() {
        return accountType;
    }

    /**
     * Set the accountType.
     * 
     * @param accountType
     *     the new accountType
     */
    public void setAccountType(IdentifierforAccounttype accountType) {
        this.accountType = accountType;
    }

    /**
     * Returns the displayName.
     * 
     * @return
     *     displayName
     */
    public String getDisplayName() {
        return displayName;
    }

    /**
     * Set the displayName.
     * 
     * @param displayName
     *     the new displayName
     */
    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    /**
     * Returns the description.
     * 
     * @return
     *     description
     */
    public String getDescription() {
        return description;
    }

    /**
     * Set the description.
     * 
     * @param description
     *     the new description
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * Returns the status.
     * 
     * @return
     *     status
     */
    public IdentifierforAccoundstatus getStatus() {
        return status;
    }

    /**
     * Set the status.
     * 
     * @param status
     *     the new status
     */
    public void setStatus(IdentifierforAccoundstatus status) {
        this.status = status;
    }

    /**
     * Returns the accountDescriptorId.
     * 
     * @return
     *     accountDescriptorId
     */
    public Double getAccountDescriptorId() {
        return accountDescriptorId;
    }

    /**
     * Set the accountDescriptorId.
     * 
     * @param accountDescriptorId
     *     the new accountDescriptorId
     */
    public void setAccountDescriptorId(Double accountDescriptorId) {
        this.accountDescriptorId = accountDescriptorId;
    }

    /**
     * Returns the customerId.
     * 
     * @return
     *     customerId
     */
    public String getCustomerId() {
        return customerId;
    }

    /**
     * Set the customerId.
     * 
     * @param customerId
     *     the new customerId
     */
    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public int hashCode() {
        return new HashCodeBuilder().append(accountId).append(accountType).append(displayName).append(description).append(status).append(accountDescriptorId).append(customerId).toHashCode();
    }

    public boolean equals(Object other) {
        if (other == null) {
            return false;
        }
        if (other == this) {
            return true;
        }
        if (this.getClass()!= other.getClass()) {
            return false;
        }
        Accountdescriptor otherObject = ((Accountdescriptor) other);
        return new EqualsBuilder().append(accountId, otherObject.accountId).append(accountType, otherObject.accountType).append(displayName, otherObject.displayName).append(description, otherObject.description).append(status, otherObject.status).append(accountDescriptorId, otherObject.accountDescriptorId).append(customerId, otherObject.customerId).isEquals();
    }

    public String toString() {
        return new ToStringBuilder(this).append("accountId", accountId).append("accountType", accountType).append("displayName", displayName).append("description", description).append("status", status).append("accountDescriptorId", accountDescriptorId).append("customerId", customerId).toString();
    }

}
