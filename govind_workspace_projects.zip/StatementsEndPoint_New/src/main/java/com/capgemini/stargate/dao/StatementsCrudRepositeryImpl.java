package com.capgemini.stargate.dao;

import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.capgemini.stargate.controller.model.Statement;
import com.capgemini.stargate.service.StatementsCrudRepositery;

@SuppressWarnings("rawtypes")
@Repository
@Transactional

public class StatementsCrudRepositeryImpl
{
	@Autowired
	public StatementsCrudRepositery statementsCrudRepositery;
	
	/*
	 * This Method fetch all statements for 
	 */
	@SuppressWarnings("unchecked")
	public List<Statement> getStatements(String accountId, String accoutType, Date startDate, Date endDate) 
	{    		 
    	 List<Statement> listaccount= statementsCrudRepositery.fetchStatementList(accountId, accoutType, startDate, endDate);
    	 
         return listaccount;

   }

	 

	
}
