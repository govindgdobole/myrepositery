package com.capgemini.stargate.service;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.NoRepositoryBean;

/*
 * StatementsCrudRepositeryInterface extends JpaRepository interface and acquire properties from JpaRepository
 */
@SuppressWarnings("hiding")
@NoRepositoryBean
public interface StatementsCrudRepositery<Statement> extends JpaRepository<Statement,String>
{
	// this method fetch list of statements for given accountID, accoutType, startDate, endDate
	@org.springframework.data.jpa.repository.Query(value = "SELECT * " + " FROM statement st , accountdescriptor  ades "
			+ "WHERE  st.AccountId = ades.AccountId "
			+ "AND statement.StatementDate BETWEEN st.startDate =:startDate AND st.endDate =:endDate ", nativeQuery = true)
	public List<Statement> fetchStatementList(String accountId, String accoutType, Date startDate, Date endDate);		

}