
package com.example.demo.controller.model;

import java.io.Serializable;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

public class Stateunion implements Serializable
{

    final static long serialVersionUID = 6271876019609198855L;
    private Statement statementlist;
    private Account accountlist;

    /**
     * Creates a new Stateunion.
     * 
     */
    public Stateunion() {
        super();
    }

    /**
     * Creates a new Stateunion.
     * 
     */
    public Stateunion(Statement statementlist, Account accountlist) {
        super();
        this.statementlist = statementlist;
        this.accountlist = accountlist;
    }

    /**
     * Returns the statementlist.
     * 
     * @return
     *     statementlist
     */
    public Statement getStatementlist() {
        return statementlist;
    }

    /**
     * Set the statementlist.
     * 
     * @param statementlist
     *     the new statementlist
     */
    public void setStatementlist(Statement statementlist) {
        this.statementlist = statementlist;
    }

    /**
     * Returns the accountlist.
     * 
     * @return
     *     accountlist
     */
    public Account getAccountlist() {
        return accountlist;
    }

    /**
     * Set the accountlist.
     * 
     * @param accountlist
     *     the new accountlist
     */
    public void setAccountlist(Account accountlist) {
        this.accountlist = accountlist;
    }

    public int hashCode() {
        return new HashCodeBuilder().append(statementlist).append(accountlist).toHashCode();
    }

    public boolean equals(Object other) {
        if (other == null) {
            return false;
        }
        if (other == this) {
            return true;
        }
        if (this.getClass()!= other.getClass()) {
            return false;
        }
        Stateunion otherObject = ((Stateunion) other);
        return new EqualsBuilder().append(statementlist, otherObject.statementlist).append(accountlist, otherObject.accountlist).isEquals();
    }

    public String toString() {
        return new ToStringBuilder(this).append("statementlist", statementlist).append("accountlist", accountlist).toString();
    }

}
