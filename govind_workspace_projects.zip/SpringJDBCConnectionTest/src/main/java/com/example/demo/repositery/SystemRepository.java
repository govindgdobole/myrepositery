package com.example.demo.repositery;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
 

@Repository
public interface SystemRepository extends CrudRepository<System,Long> {
     
 
}
