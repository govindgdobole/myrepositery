package com.capgemini.stargate.repositery;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.NoRepositoryBean;

@SuppressWarnings("hiding")
@NoRepositoryBean
public interface StatementsCrudRepositeryInterface<Statement> extends JpaRepository<Statement,String>
{
	// write a method to list of statements
	public List<Statement> fetchStatementList(String accountId, String accoutType, Date startDate, Date endDate);		
	

}