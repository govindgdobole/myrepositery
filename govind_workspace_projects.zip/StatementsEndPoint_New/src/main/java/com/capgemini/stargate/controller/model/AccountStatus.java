
package com.capgemini.stargate.controller.model;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonProperty;

/*
 * AccountStatus is enum with necessary methods & annotations and it gets generated from RAML plugin
 */
public enum AccountStatus {

    @JsonProperty("OPEN")
    OPEN("OPEN"),
    @JsonProperty("CLOSED")
    CLOSED("CLOSED"),
    @JsonProperty("PENDINGOPEN")
    PENDINGOPEN("PENDINGOPEN"),
    @JsonProperty("PENDINGCLOSE")
    PENDINGCLOSE("PENDINGCLOSE"),
    @JsonProperty("DELINQUENT")
    DELINQUENT("DELINQUENT"),
    @JsonProperty("PAID")
    PAID("PAID"),
    @JsonProperty("NEGATIVECURRENTBALANCE")
    NEGATIVECURRENTBALANCE("NEGATIVECURRENTBALANCE");
    private final String value;
    private final static Map<String, AccountStatus> VALUE_CACHE = new HashMap<String, AccountStatus>();

    static {
        for (AccountStatus c: values()) {
            VALUE_CACHE.put(c.value, c);
        }
    }

    private AccountStatus(String value) {
        this.value = value;
    }

    public String value() {
        return this.value;
    }

    public static AccountStatus fromValue(String value) {
        return VALUE_CACHE.get(value);
    }

    @Override
    public String toString() {
        return this.value;
    }

}
