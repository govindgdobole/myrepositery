package com.capgemini.stargate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/*
 * Its spring boot default main class and its runs with main method.
 */
@SpringBootApplication
//@EnableOAuth2Sso
public class StatementsEndPointNewApplication {
	// main method
	public static void main(String[] args) {		
		SpringApplication.run(StatementsEndPointNewApplication.class, args);
	}
}
