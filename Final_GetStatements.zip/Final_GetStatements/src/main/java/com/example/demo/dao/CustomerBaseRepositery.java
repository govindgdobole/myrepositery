package com.example.demo.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.demo.controller.model.AccountDescriptor;


public interface CustomerBaseRepositery extends JpaRepository<AccountDescriptor, String>{
	
	@Query(value = "SELECT accountdescriptor.CustomerId from accountdescriptor  where accountdescriptor.AccountId", nativeQuery = true)
	public List<String> fetchCustIdDetails(@Param("AccountId") String accountId);

}

