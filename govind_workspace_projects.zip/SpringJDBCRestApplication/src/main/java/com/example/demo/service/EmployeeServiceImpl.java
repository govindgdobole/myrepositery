package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.bean.Employee;


@Service("employeeService")
public class EmployeeServiceImpl implements EmployeeService {
 @Autowired
 private EmployeeService employeeService;

 public List<Employee> getEmployees() {
  List<Employee> employees = employeeService.getEmployees();
  return employees;
 }

 public Employee getEmployee(Long employeeId) {
  Employee employee = employeeService.getEmployee(employeeId);
  return employee;
 }

 public int deleteEmployee(Long employeeId) {
  return employeeService.deleteEmployee(employeeId);
 }

 public int updateEmployee(Employee employee) {
  return employeeService.updateEmployee(employee);
 }

 public int createEmployee(Employee employee) {
  return employeeService.createEmployee(employee);
 }
}