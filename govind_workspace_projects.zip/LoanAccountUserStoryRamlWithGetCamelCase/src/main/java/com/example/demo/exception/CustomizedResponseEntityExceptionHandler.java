package com.example.demo.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
@RestController
public class CustomizedResponseEntityExceptionHandler extends ResponseEntityExceptionHandler {

	@ExceptionHandler(value = LoanAccountNotFoundException.class)
	public final ResponseEntity<ExceptionResponse> handleLoanAccountNotFoundException(LoanAccountNotFoundException ex) {
		ExceptionResponse exceptionResponse = new ExceptionResponse("Loan acount not found", "404");
		return new ResponseEntity<>(exceptionResponse, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(value = BadRequestException.class)
	public final ResponseEntity<ExceptionResponse> forBadRequest(BadRequestException ex) {
		ExceptionResponse exceptionResponse = new ExceptionResponse("Bad request", "400");
		return new ResponseEntity<>(exceptionResponse, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(value = HeaderNotAcceptableException.class)
	public final ResponseEntity<ExceptionResponse> handleHeaderNotAcceptableException(HeaderNotAcceptableException ex) {
		ExceptionResponse exceptionResponse = new ExceptionResponse("Request Header is not acceptable", "406");
		return new ResponseEntity<>(exceptionResponse, HttpStatus.NOT_ACCEPTABLE);
	}


	@ExceptionHandler(Exception.class)
	public final ResponseEntity<ExceptionResponse> handleAllExceptions(Exception ex) {
		ExceptionResponse exceptionResponse = new ExceptionResponse("Please contact admin", "500");
		return new ResponseEntity<>(exceptionResponse, HttpStatus.INTERNAL_SERVER_ERROR);
	}
}
