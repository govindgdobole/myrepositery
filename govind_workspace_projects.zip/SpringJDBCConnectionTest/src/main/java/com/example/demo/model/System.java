package com.example.demo.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
 
@Entity
@Table(name="my_system")
public class System {
 
	@Id
    @Column(name="id")
    private long id;
	
	@Column(name="name")	
	private String name;
    
	@Column(name="lastaudit")
	private Date lastaudit;
    
    System(){};
    
    public Date getLastaudit() {
        return lastaudit;
    }
    public void setLastaudit(Date lastaudit) {
        this.lastaudit = lastaudit;
    }
        
   
    public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
     
    public String toString(){
        return id+" | " + name+ " | "+ lastaudit;
    }
     
}
