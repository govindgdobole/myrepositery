
package com.capgemini.stargate.controller.model;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonProperty;

/*
 * Account is enum with necessary methods & annotations its generated from RAML plugin
 */
public enum PaymentFrequency {

    @JsonProperty("WEEKLY")
    WEEKLY("WEEKLY"),
    @JsonProperty("BIWEEKLY")
    BIWEEKLY("BIWEEKLY"),
    @JsonProperty("TWICEMONTHLY")
    TWICEMONTHLY("TWICEMONTHLY"),
    @JsonProperty("MONTHLY")
    MONTHLY("MONTHLY"),
    @JsonProperty("FOURWEEKS")
    FOURWEEKS("FOURWEEKS"),
    @JsonProperty("BIMONTHLY")
    BIMONTHLY("BIMONTHLY"),
    @JsonProperty("QUARTERLY")
    QUARTERLY("QUARTERLY"),
    @JsonProperty("SEMIANNUALLY")
    SEMIANNUALLY("SEMIANNUALLY"),
    @JsonProperty("ANNUALLY")
    ANNUALLY("ANNUALLY"),
    @JsonProperty("OTHER")
    OTHER("OTHER");
    private final String value;
    private final static Map<String, PaymentFrequency> VALUE_CACHE = new HashMap<String, PaymentFrequency>();

    static {
        for (PaymentFrequency c: values()) {
            VALUE_CACHE.put(c.value, c);
        }
    }

    private PaymentFrequency(String value) {
        this.value = value;
    }

    public String value() {
        return this.value;
    }

    public static PaymentFrequency fromValue(String value) {
        return VALUE_CACHE.get(value);
    }

    @Override
    public String toString() {
        return this.value;
    }

}
