package com.example.demo.soap;

import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.demo.controller.model.Loanaccount;
import com.google.gson.Gson;

public class LoanAccountSoap {

	
	@Autowired
	BankCatalogClient bankCatalogClient;

	StringBuilder result;
	
	public Boolean getSoapResponseById(List<Loanaccount> listloanaccount) {
		
		Iterator iter = listloanaccount.iterator();
	      while (iter.hasNext()) {
	    	  Loanaccount acc = (Loanaccount)iter.next();
	    	  String customerid = acc.getCustomerId();
	      
		      GetBankDetailsResponse response = bankCatalogClient.getBankById(customerid);
		      Gson gson = new Gson();
		     
		       //result = gson.toJson(response).toString();
		       System.out.println(gson.toJson(response).toString());
	      }
		
		return true;
	}
}
