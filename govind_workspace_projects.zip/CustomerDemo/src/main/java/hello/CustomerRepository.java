package hello;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import io.spring.guides.customerdemo.Customer;

@Component
public class CustomerRepository {
	private static final Map<Integer, Customer> cust = new HashMap<>();

	@PostConstruct
	public void initData() {
		
		Customer cs1 = new Customer();
		cs1.setName("Govind");
		cs1.setId(111);
		cs1.setAddress("Pune");
		cs1.setContact(1234567890);
		
		cust.put(cs1.getId(), cs1);
		
		Customer cs2 = new Customer();
		cs2.setName("Vijendra");
		cs2.setId(112);
		cs2.setAddress("Pune");
		cs2.setContact(789023423);
		
		cust.put(cs2.getId(), cs2);
		
		Customer cs3 = new Customer();
		cs3.setName("Pankaj");
		cs3.setId(113);
		cs3.setAddress("Pune");
		cs3.setContact(1253267890);
		
		cust.put(cs3.getId(), cs3);
	}
	
	/*
	 * Return customers with particular id
	 */
	public Customer getCustomerByID(int id) {		
		Assert.notNull(cust.size(), "There is no Customer Present");				
		return cust.get(id);
	}
	
	/*
	 * Returns list of all customers( converts from map to list)
	 * 
	 */
	public List<Customer> allCustList()
	{
		List<Customer> custList = new ArrayList<>();	
		
		Set<Integer> ids = cust.keySet();
		for(Integer id: ids){
			custList.add(cust.get(id));
			id++;
		}
		return custList;
	}
}
