com.example.demo.soapservice;

public class BankCatalogClient extends WebServiceGatewaySupport {

	public GetBankDetailsResponse getBankById(String id) {
		GetBankDetailsRequest request = new GetBankDetailsRequest();
		request.setCustomerId(id);
		GetBankDetailsResponse response = (GetBankDetailsResponse) getWebServiceTemplate()
				.marshalSendAndReceive(request, new SoapActionCallback("http://34.236.109.151:8000/ws/"));
		return response;
	}
}