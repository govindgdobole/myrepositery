
package com.capgemini.stargate.controller.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonFormat;

/*
 * LoanAccount is pojo class with necessary variables & methods & annotations its generated from RAML plugin
 */
public class LoanAccount
    extends Account
    implements Serializable
{

    final static long serialVersionUID = 86504375650385370L;
    @JsonFormat(pattern = "yyyy-MM-dd")
    
    @Column(name="BalanceAsOf")
    private Date balanceAsOf;
    
    @Column(name="PrincipalBalance")
    private Double principalBalance;
    
    @Column(name="OriginalPrincipal")
    private Double originalPrincipal;
    
    @Enumerated(EnumType.STRING)
    private PaymentFrequency paymentFrequency;    
    
    @Id
    @Column(name="LoanAccountId")
    private Double loanAccountId;    

	/**
     * Creates a new LoanAccount.
     * 
     */
    public LoanAccount() {
        super();
    }

    /**
     * Creates a new LoanAccount.
     * 
     */
    public LoanAccount(Double accountMasterId,String accountId, AccountType accountType, String displayName, String description, AccountStatus accountStatus, String parentAccountId, String nickname, String accountNumber, Double interestRate, com.capgemini.stargate.controller.model.Currency Currency, Date balanceAsOf, Double principalBalance, Double originalPrincipal, Double accountDescriptorId, PaymentFrequency paymentFrequency, Double loanAccountId) {
        super(accountMasterId,accountId, accountType, displayName, description, accountStatus, parentAccountId, nickname, accountNumber, interestRate, accountDescriptorId,Currency);
        this.balanceAsOf = balanceAsOf;
        this.principalBalance = principalBalance;
        this.originalPrincipal = originalPrincipal;
        this.paymentFrequency = paymentFrequency;
        this.accountDescriptorId = accountDescriptorId;
        this.accountMasterId = accountMasterId;
        this.loanAccountId = loanAccountId;
    }

    /**
     * Returns the balanceAsOf.
     * 
     * @return
     *     balanceAsOf
     */
    public Date getBalanceAsOf() {
        return balanceAsOf;
    }

    /**
     * Set the balanceAsOf.
     * 
     * @param balanceAsOf
     *     the new balanceAsOf
     */
    public void setBalanceAsOf(Date balanceAsOf) {
        this.balanceAsOf = balanceAsOf;
    }

    /**
     * Returns the principalBalance.
     * 
     * @return
     *     principalBalance
     */
    public Double getPrincipalBalance() {
        return principalBalance;
    }

    /**
     * Set the principalBalance.
     * 
     * @param principalBalance
     *     the new principalBalance
     */
    public void setPrincipalBalance(Double principalBalance) {
        this.principalBalance = principalBalance;
    }

    /**
     * Returns the originalPrincipal.
     * 
     * @return
     *     originalPrincipal
     */
    public Double getOriginalPrincipal() {
        return originalPrincipal;
    }

    /**
     * Set the originalPrincipal.
     * 
     * @param originalPrincipal
     *     the new originalPrincipal
     */
    public void setOriginalPrincipal(Double originalPrincipal) {
        this.originalPrincipal = originalPrincipal;
    }

    /**
     * Returns the paymentFrequency.
     * 
     * @return
     *     paymentFrequency
     */
    public PaymentFrequency getPaymentFrequency() {
        return paymentFrequency;
    }

    /**
     * Set the paymentFrequency.
     * 
     * @param paymentFrequency
     *     the new paymentFrequency
     */
    public void setPaymentFrequency(PaymentFrequency paymentFrequency) {
        this.paymentFrequency = paymentFrequency;
    }
    
    public Double getLoanAccountId() {
		return loanAccountId;
	}

	public void setLoanAccountId(Double loanAccountId) {
		this.loanAccountId = loanAccountId;
	}

    public int hashCode() {
        return new HashCodeBuilder().appendSuper(super.hashCode()).append(balanceAsOf).append(principalBalance).append(originalPrincipal).append(paymentFrequency).toHashCode();
    }

    public boolean equals(Object other) {
        if (other == null) {
            return false;
        }
        if (other == this) {
            return true;
        }
        if (this.getClass()!= other.getClass()) {
            return false;
        }
        LoanAccount otherObject = ((LoanAccount) other);
        return new EqualsBuilder().appendSuper(super.equals(otherObject)).append(balanceAsOf, otherObject.balanceAsOf).append(principalBalance, otherObject.principalBalance).append(originalPrincipal, otherObject.originalPrincipal).append(paymentFrequency, otherObject.paymentFrequency).isEquals();
    }

    public String toString() {
        return new ToStringBuilder(this).appendSuper(super.toString()).append("balanceAsOf", balanceAsOf).append("principalBalance", principalBalance).append("originalPrincipal", originalPrincipal).append("paymentFrequency", paymentFrequency).toString();
    }

}
